package com.example.dataoptimizer.vpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService

object VpnPermissionHelper {
    const val REQUEST_VPN = 1000

    fun prepareVpn(activity: Activity): Boolean {
        val intent = VpnService.prepare(activity)
        return if (intent != null) {
            activity.startActivityForResult(intent, REQUEST_VPN)
            false
        } else {
            // تمت الموافقة سابقًا
            true
        }
    }
}