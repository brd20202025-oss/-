# Copilot Chat Conversation Export: Build Android app with VPN service

**User:** @brd20202025-oss
**Thread URL:** https://github.com/copilot/c/20fa86bb-6446-48b5-91af-1a40f689ff55

## @brd20202025-oss

نص الوصف للذكاء الاصطناعي:
​"أريدك أن تعمل كمهندس برمجيات ومطور تطبيقات أندرويد محترف. أريد تصميم وتطوير تطبيق أندرويد متكامل بلغة Kotlin ومبني بالكامل باللغة العربية، وظيفته الرئيسية هي تنظيم والتحكم في استهلاك إنترنت الواي فاي وبيانات الهاتف باستخدام تقنية الـ VPN المحلي (Local VPN Service).
​الميزات الأساسية المطلوب برمجتها والتخطيط لها في التطبيق:
​نظام الحصص الذكي (Quotas):
​إمكانية تحديد باقة شهرية إجمالية يقوم التطبيق بقسمتها تلقائياً على 30 يوماً.
​إمكانية تحديد حصة يومية محددة (مثلاً: 500 ميجابايت في اليوم) مع تحديد ساعات التشغيل خلال اليوم (مثل 12 ساعة).
​القطع التلقائي (Kill Switch / Traffic Block):
​مراقبة حجم البيانات المستهلكة (صادرة وواردة) لحظياً عبر خدمة الـ VPN.
​قطع وفصل الإنترنت تلقائياً عن التطبيقات عند نفاذ الحصة اليومية المحددة، وإعادة تعيين العداد تلقائياً في منتصف الليل باستخدام (WorkManager).
​التحكم والتمييز: إمكانية تطبيق الحصص إما على بيانات الهاتف وحدها أو على الواي فاي والبيانات معاً، مع إرسال تنبيهات للمستخدم عند استهلاك نسبة كبيرة من الحصة (مثل 80%).
​واجهة المستخدم (UI): واجهة بسيطة وعصرية باللغة العربية بالكامل، تدعم الوضع الداكن (Dark Mode).
​مطلب هام في واجهة تسجيل الدخول أو الشاشة الرئيسية:
​يجب أن يتم وضع النص التالي بشكل أنيق وواضح في أسفل الصفحة الرئيسية أو شاشة الدخول:
(توجيه وبرمجه عبد الحق الغولي).
​أريدك أن تبدأ بتزويدي بالهيكل الأساسي للمشروع (Project Structure)، وكيفية بناء خدمة الـ VpnService برمجياً، وكيفية حساب وتتبع كمية البيانات المستهلكة بالبايت والميجابايت."
​يمكنك نسخ هذا النص مباشرة ولصقه في الذكاء الاصطناعي الذي ستعتمد عليه في كتابة الأكواد، وسيعطيك فهماً هندسياً دقيقاً وشاملاً لكيفية بناء تطبيقك! بالتوفيق في مشروعك يا عبد الحق.

## Copilot

جميل — سأبدأ بخطّة هندسية واضحة بالعربية مع أمثلة كود Kotlin قابلة للاستخدام كمقتطفات. سأقدّم:

- هيكل المشروع المقترح (ملفّات ومجلدات أساسية).
- تنفيذ خدمة Local VpnService برمجياً (DataVpnService) مع عدّّ المستهلك من البايتات.
- كيف تُحوّل البايتات إلى ميجابايت/غيغابايت وكيف تُخزّن وتحسب الحصص اليومية/الشهرية.
- ملحوظات أمان وقيود منصّة أندرويد.
- مثال Worker لإعادة تعيين الحصّة عند منتصف الليل.
- أين تضع النص المطلوب في واجهة المستخدم: "توجيه وبرمجه عبد الحق الغولي".

كل شيء باللغة العربية وبمقتطفات ملفية قابلة للنسخ.

1) هيكل المشروع المقترح
- app/
  - src/
    - main/
      - java/com/example/dataoptimizer/
        - ui/
          - MainActivity.kt
          - LoginActivity.kt (اختياري)
        - vpn/
          - DataVpnService.kt
        - data/
          - local/
            - PrefsManager.kt
          - repository/
            - DataUsageRepository.kt
        - workers/
          - ResetQuotaWorker.kt
        - util/
          - DataConverter.kt
          - QuotaCalculator.kt
      - res/
        - layout/
          - activity_main.xml
        - values/
          - strings.xml
          - themes.xml
        - drawable/
          - card_bg.xml
      - AndroidManifest.xml
- build.gradle.kts, settings.gradle.kts, gradle.properties, README_AR.md

2) نقاط مهمة قبل البدء
- Local VPN يتطلّب موافقة المستخدم؛ عليك استدعاء VpnService.prepare() ثم startActivityForResult.
- Local VPN يوفّر واجهة شبكة افتراضية (tun) على الجهاز؛ يمكنك قراءة وكتابة الحزم من/إلى ParcelFileDescriptor. عدّ البايتات يتم عبر قراءة/كتابة الفلو.
- لا يمكن إعادة توجيه الحزم إلى الإنترنت دون كود متقدّم (forwarding / userspace TCP stack). لكن لإنشاء "قطْع" يمكنك ببساطة عدم معاودة توجيه أو إسقاط الحزم (بمعنى: عند نفاد الحصة لا تقوم بتمرير الحزم من/إلى الشبكة).
- تتطلب بعض الميزات صلاحيات إضافية أو تعاملات مع Doze وBattery optimizations.

3) مثال: خدمة Local VPN أساسية (تحتسب البايتات وتنفّذ قطع عند نفاد الحصة)
- ملف الخدمة:

```kotlin name=DataVpnService.kt
package com.example.dataoptimizer.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.example.dataoptimizer.data.local.PrefsManager
import com.example.dataoptimizer.util.QuotaCalculator
import kotlinx.coroutines.*
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.coroutines.CoroutineContext

class DataVpnService : VpnService(), CoroutineScope {
    private var vpnInterface: ParcelFileDescriptor? = null
    private var job: Job = Job()
    override val coroutineContext: CoroutineContext
        get() = Dispatchers.IO + job

    private lateinit var prefs: PrefsManager

    // عداد مؤقّت لبايتات الجلسة الحالية
    @Volatile
    private var sessionRxBytes: Long = 0L

    @Volatile
    private var sessionTxBytes: Long = 0L

    companion object {
        const val NOTIF_CHANNEL = "data_vpn_channel"
        const val NOTIF_ID = 1001
    }

    override fun onCreate() {
        super.onCreate()
        prefs = PrefsManager(this)
        startForegroundWithNotification()
    }

    private fun startForegroundWithNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel =
                NotificationChannel(NOTIF_CHANNEL, "خدمة التحكم بالبيانات", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(channel)
        }
        val notif: Notification = NotificationCompat.Builder(this, NOTIF_CHANNEL)
            .setContentTitle("خدمة Data Optimizer تعمل")
            .setContentText("مراقبة استهلاك البيانات")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .build()
        startForeground(NOTIF_ID, notif)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // إعداد وبدء VPN في الخلفية
        launch {
            establishVpn()
            runVpnLoop()
        }
        return START_STICKY
    }

    private fun establishVpn() {
        // إيقاف إنشاءة متعددة
        vpnInterface?.closeQuietly()

        val builder = Builder()
        builder.setSession("DataOptimizerLocalVPN")
            // عنوان افتراضي داخل الشبكة الافتراضية
            .addAddress("10.0.0.2", 32)
            // مسار افتراضي لالتقاط كل الحزم
            .addRoute("0.0.0.0", 0)
        // استثناء التطبيقات المسموح لها (مثال): يمكنك التحكم عبر واجهة المستخدم
        // builder.addAllowedApplication("com.example.app")

        // MTU اختياري
        builder.setMtu(1500)

        vpnInterface = builder.establish()
    }

    private suspend fun runVpnLoop() {
        val pfd = vpnInterface ?: return
        val `in` = FileInputStream(pfd.fileDescriptor)
        val out = FileOutputStream(pfd.fileDescriptor)
        val buffer = ByteArray(32767)

        // عند نفاد الحصة نوقف إعادة التوجيه (ببساطة نتجاهل الحزم)
        while (isActive) {
            // تحقق من الحصة قبل القراءة لمعرفة ما إذا نحتاج إلى إسقاط/حظر
            val dailyQuotaBytes = QuotaCalculator.getDailyQuotaBytes(this, prefs)
            val usedToday = prefs.getUsedBytesToday()
            if (usedToday >= dailyQuotaBytes) {
                // إسقاط الحزم: نقرأ فقط بدون إعادة توجيه أو نؤخر القراءة
                delay(1000) // تقليل استهلاك CPU أثناء الحظر
                continue
            }

            // قراءة بيانات من الواجهة الافتراضية (حزم صادرة من التطبيقات إلى الشبكة)
            val read = try {
                `in`.read(buffer)
            } catch (e: Exception) {
                -1
            }
            if (read > 0) {
                // عدّ البايتات الصادرة
                sessionTxBytes += read
                prefs.addUsedBytes(read.toLong())
                // هنا عادةً يجب عليك إعادة توجيه الحزمة إلى الشبكة الحقيقية (userspace stack أو raw sockets)
                // إذا أردت عرض/إحصاء فقط، يمكنك تجاهل إعادة التوجيه أو implement forwarding لاحقاً.
            } else if (read == -1) {
                break
            }

            // ملاحظة: لقراءة الحزم الواردة يجب فتح socket خارجي وقراءة، أو ضمن بنية إعادة التوجيه.
            // لكن حتى لو لم تعيد توجيه الحزم، قراءة المخرجات تتيحك عدّ ما ترسل التطبيقات.
            // يمكن أيضاً استخدام TrafficStats για قياس إجمالي النظام كاحتياط.
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        job.cancel()
        vpnInterface?.closeQuietly()
        stopForeground(true)
    }

    override fun onRevoke() {
        super.onRevoke()
        onDestroy()
    }

    // مساعدة لإغلاق ParcelFileDescriptor بأمان
    private fun ParcelFileDescriptor?.closeQuietly() {
        try {
            this?.close()
        } catch (e: Exception) {
            // ignore
        }
    }
}
```

شرح موجز:
- ننشئ Builder مع addAddress و addRoute لالتقاط كل الحزم.
- establish() يعيد ParcelFileDescriptor تمثّل الواجهة TUN.
- قراءة من FileInputStream على pfd.fileDescriptor تُمثّل الحزم الصادرة من التطبيقات؛ عدد البايتات المقروءة هو TX من منظور التطبيقات. لعد RX الحقيقي تحتاج إلى إعادة توجيه الحزم إلى الشبكة وقراءة الردود، أو يمكنك الاعتماد على TrafficStats كنقطة مرجعية عامة.
- عندما تتجاوز الحصة اليومية المخزَّنة في SharedPreferences، نقوم بـ "إسقاط الحزم" عبر تجاهل إعادة التوجيه أو عدم السماح بتمريرها — هذا يحقق وظيفة Kill Switch البسيطة.
- ملاحظة: تنفيذ إعادة التوجيه الكامل يتطلب بناء userspace network stack أو استخدام native libraries — هذا خارج نطاق البداية، لكن العدّ والحظر ممكنان.

4) حفظ وقراءة البايتات في PrefsManager (تعديل خفيف مقترح)
الـ PrefsManager الحالي يحفظ الحصة (ميغابايت) فقط. أضيف حقول لتخزين استخدام اليوم والوقت الأخير لإعادة التصفير.

```kotlin name=PrefsManager.kt
package com.example.dataoptimizer.data.local

import android.content.Context
import java.util.Calendar

class PrefsManager(context: Context) {
    private val prefs = context.getSharedPreferences("data_optimizer_prefs", Context.MODE_PRIVATE)

    fun getQuotaMb(): Double = prefs.getString("quota_mb", "1024")?.toDoubleOrNull() ?: 1024.0
    fun setQuotaMb(value: Double) {
        prefs.edit().putString("quota_mb", value.toString()).apply()
    }

    // استخدام يومي بالبايت
    fun getUsedBytesToday(): Long = prefs.getLong("used_bytes_today", 0L)
    fun setUsedBytesToday(value: Long) = prefs.edit().putLong("used_bytes_today", value).apply()
    fun addUsedBytes(delta: Long) {
        val current = getUsedBytesToday()
        setUsedBytesToday(current + delta)
    }

    // تاريخ آخر إعادة تعيين (باليوم)
    fun getLastResetDay(): Int = prefs.getInt("last_reset_day", -1)
    fun setLastResetDay(dayOfYear: Int) = prefs.edit().putInt("last_reset_day", dayOfYear).apply()
}
```

5) حساب الحصص (يومي/شهري) ووظيفة تحويل البايتات
- QuotaCalculator يوفر دوال لتحويل وتوزيع الحصة الشهرية على 30 يوماً.

```kotlin name=QuotaCalculator.kt
package com.example.dataoptimizer.util

import android.content.Context
import com.example.dataoptimizer.data.local.PrefsManager

object QuotaCalculator {
    // تحويل ميجابايت إلى بايت
    fun mbToBytes(mb: Double): Long = (mb * 1024.0 * 1024.0).toLong()

    // تحويل بايت إلى ميجابايت
    fun bytesToMb(bytes: Long): Double = bytes / (1024.0 * 1024.0)

    // إذا المستخدم حدّد حصة شهرية إجمالية، نوزّعها على 30 يوم
    fun getDailyQuotaBytes(context: Context, prefs: PrefsManager): Long {
        val monthlyMb = prefs.getQuotaMb()
        val dailyMb = monthlyMb / 30.0
        return mbToBytes(dailyMb)
    }
}
```

- DataConverter لديك جيد؛ استخدمه لعرض القيم.

6) Worker لإعادة الضبط عند منتصف الليل باستخدام WorkManager
- مثال ResetQuotaWorker يقوم بالتحقّق من اليوم الحالي وإذا اختلف عن آخر إعادة، يعيد الصفر.

```kotlin name=ResetQuotaWorker.kt
package com.example.dataoptimizer.workers

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.dataoptimizer.data.local.PrefsManager
import java.util.Calendar

class ResetQuotaWorker(private val ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    private val prefs = PrefsManager(ctx)
    override suspend fun doWork(): Result {
        val cal = Calendar.getInstance()
        val today = cal.get(Calendar.DAY_OF_YEAR)
        val last = prefs.getLastResetDay()
        if (last != today) {
            prefs.setUsedBytesToday(0L)
            prefs.setLastResetDay(today)
        }
        return Result.success()
    }
}
```

جدولة:
- يمكنك جدولة WorkManager ليعمل مرة واحدة يومياً عند ساعات محددة أو استخدام PeriodicWorkRequest مع تكرار 24 ساعة. ضع في الاعتبار قيود Doze — أفضل أن تشغّل WorkManager مع وقت مرن أو تفعيل الآن عند تشغيل التطبيق.

7) طلب إذن VPN من المستخدم في Activity
- في واجهة الاستخدام اطلب موافقة المستخدم قبل startService:

```kotlin name=VpnPermissionHelper.kt
package com.example.dataoptimizer.vpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService

object VpnPermissionHelper {
    const val REQUEST_VPN = 1000

    fun prepareVpn(activity: Activity): Boolean {
        val intent = VpnService.prepare(activity)
        return if (intent != null) {
            activity.startActivityForResult(intent, REQUEST_VPN)
            false
        } else {
            // تمت الموافقة سابقًا
            true
        }
    }
}
```

وفي Activity:

```kotlin name=MainActivity-VpnStartSnippet.kt
// مثال مقتطف داخل MainActivity
if (VpnPermissionHelper.prepareVpn(this)) {
    // بدء الخدمة مباشرة
    startService(Intent(this, DataVpnService::class.java))
}
// في onActivityResult تحقّق ثم ابدأ الخدمة إذا تم المنح
```

8) عرض النص المطلوب في أسفل الشاشة الرئيسية
ضع النص العربي "توجيه وبرمجه عبد الحق الغولي" في layout أسفل الصفحة. مثال لجزء من XML:

```xml name=activity_main_footer.xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:gravity="center"
    android:padding="12dp">

    <TextView
        android:id="@+id/footerBy"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="توجيه وبرمجه عبد الحق الغولي"
        android:textAlignment="center"
        android:textSize="12sp"
        android:textColor="?android:attr/textColorSecondary" />
</LinearLayout>
```

9) كيفية حساب وعرض الاستخدام (بايت → ميجابايت)
- استخدم QuotaCalculator.bytesToMb أو DataConverter.formatUsage لعرض القيمة.
- حافظ على الدقة عند التخزين (خزن بالبايت في SharedPreferences أو قاعدة بيانات).

10) قيود واعتبارات فنية وأمنية
- Local VPN يحتاج موافقة المستخدم ويؤثر على كل حركة الجهاز إذا لم تحدد استثناءات للتطبيقات.
- لإعادة توجيه فعلي (تمرير الحزم فعلياً إلى الإنترنت) تحتاج إلى بناء userspace network stack أو استخدام مكتبيات جاهزة (مثال: tun2socks أو مكتبات native) — هذا يجعل التطبيق معقد جداً.
- بعض الأجهزة أو إصدارات أندرويد قد تقيّد عمل VpnService أو تعطّل بعض الميزات (Doze، Battery Saver).
- مراقبة per-app دقيقة تتطلب استخدام addAllowedApplication/addDisallowedApplication (يجب أن تطلب PackageManager.getPackageInfo() وأذونات).

11) تغييرات مقترَحة على الملفات الموجودة في المشروع المُرسل
- أضف DataVpnService.kt كما في المثال.
- حدّث PrefsManager.kt كما في المقتطف لتخزين usedBytesToday وlastResetDay.
- أضف ResetQuotaWorker.kt إلى workers وجدوله عند تشغيل التطبيق (PeriodicWorkRequest أو AlarmManager حسب تفضيلك).
- حدّث AndroidManifest.xml لإضافة تصريح الخدمة:

```xml name=AndroidManifest.xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.example.dataoptimizer">

    <application
        ...>
        <service
            android:name="com.example.dataoptimizer.vpn.DataVpnService"
            android:permission="android.permission.BIND_VPN_SERVICE"
            android:exported="false" />
    </application>

</manifest>
```

12) مثال سريع لعرض حالة الحصة في MainActivity (مقتطف)
```kotlin name=MainActivity-QuotaSnippet.kt
// داخل MainActivity بعد تهيئة prefs
fun updateUsageUI() {
    val usedBytes = prefs.getUsedBytesToday()
    val dailyQuota = QuotaCalculator.getDailyQuotaBytes(this, prefs)
    binding.usageText.text = DataConverter.formatUsage(usedBytes)
    binding.quotaText.text = DataConverter.formatUsage(dailyQuota)
    val percent = if (dailyQuota == 0L) 0 else (usedBytes * 100 / dailyQuota).toInt()
    if (percent >= 80) {
        // إظهار إشعار/تنبيه للمستخدم عن الاقتراب من الحد
    }
}
```

13) خطوات التنفيذ الموصى بها تتابعياً
1. دمج PrefsManager المعدّل وإضافة QuotaCalculator.
2. إضافة DataVpnService وطلب إذن VPN من المستخدم عبر VpnService.prepare.
3. تنفيذ عدّ البايتات الأساسي داخل الخدمة وتخزينها في prefs (كما في الكود).
4. إضافة ResetQuotaWorker وجدولته (WorkManager) لإعادة التعيين منتصف الليل.
5. واجهة المستخدم: عرض الحصة المستهلكة والنسبة وأزرار لبدء/إيقاف الخدمة، وإدخال الحصة الشهرية/اليومية، وإمكانية تحديد التطبيقات المسموح لها.
6. لاختبار: ابدأ الخدمة على جهاز للـ debug، راقب القيم، جرّب تجاوز الحصة لتتأكّد من عمل Kill Switch (الحجب).

إذا رغبت، أستطيع الآن:
- تعديل الملفات الموجودة لديك فعلياً وكتابة DataVpnService.kt وQuotaCalculator.kt وResetQuotaWorker.kt في المشروع (أدرجت مقتطفات أعلاه).
- أوّلاً توليد ملف AndroidManifest.xml محدث، وActivity/لوحات واجهة باللغة العربية تحتوي النص المطلوب "توجيه وبرمجه عبد الحق الغولي" في الأسفل.
- أو شرح تفصيلي لآلية إعادة توجيه الحزم (forwarding) في حال أردت السماح بالاتصال مع سجلات/بروكسي أو تطبيقات محددة.

ما الذي تفضّل أن أفعله الآن؟ أريد: (أ) توليد الملفات وتعديلات الكود كاملة في المشروع، أم (ب) شرح أعمق عن إعادة التوجيه وقطع الإنترنت للتطبيقات المحدّدة؟

## @brd20202025-oss

اريد ان تجعلها ملف قابل للتنظيل

*System: User retried message*

## Copilot

هل تقصِد بــ "قابل للتنظيل" أحد المعاني التالية؟ اختر واحداً أو فسّر أكثر إن كان لديك معنى آخر:

1) "قابل للتنزيل" — ملف مضغوط (ZIP) يحتوي المشروع كاملاً يمكن تنزيله وتعديله محلياً.  
2) "قابل للتنصيب" — حزمة APK جاهزة للتثبيت على جهاز أندرويد. (هذا يتطلب بناء التطبيق عبر CI مثل GitHub Actions أو جهاز بناء محلي.)  
3) "قابل للتعديل / قابل للتحرير" — أريد جميع ملفات المشروع جاهزة للتعديل (أي: شجرة المشروع كاملة كملفات .kt و XML و build scripts).  
4) إنشاء مستودع GitHub جديد بالمشروع مع سير عمل Actions لبناء APK تلقائياً.

أي خيار تفضّل؟ إذا اخترت (2) أو (4) فأخبرني اسم المستودع (owner/repo) ورؤية المستودع (public/private).  
إذا اخترت (1) أو (3) أبدأ فوراً بتوليد جميع ملفات المشروع وإرسالها هنا كملفات جاهزة (أرسلها كقوالب ملفات في المحادثة). هل تريد أن أضمّن أيضاً كود خدمة VPN والـ Worker والتعديلات على PrefsManager كما اقترحت سابقاً؟

## @brd20202025-oss

اريد ان تجعله ملف قابل للتثبيت

*System: User retried message*

## Copilot

حسناً — سأقدّم لك كل ما تحتاجه لجعل المشروع قابلاً للبناء والحصول على ملف APK قابل للتثبيت. سأعطي:

1) ملفات ناقصة / معدّلة يجب إضافتها إلى المشروع (مسارات مقترحة).  
2) ملف سير عمل GitHub Actions لبناء APK تلقائياً (يمكنك رفع المشروع إلى GitHub ثم تشغيله لتحصل على APK منتج).  
3) تعليمات مبسطة لبناء APK محلياً باستخدام Android Studio أو باستخدام GitHub Actions.

ملاحظة مهمة: الكود المرافق لخدمة الـ VPN هنا يكفي لبناء التطبيق وبدء خدمة VpnService محلياً ولإحصاء البايتات الأساسية. إعادة توجيه الحزم الفعلية (حتى تعمل كـ proxy حقيقي) تحتاج تطوير أعمق (userspace network stack أو مكتبات native مثل tun2socks) وهو خارج نطاق هذا الرد. لكن APK سينتج ويمكن تثبيته واختبار سلوك العدّ والحظر البسيط (إسقاط الحزم داخل الخدمة).

أولاً — ملفات لتضيفها أو تستبدلها في مشروعك
أدناه ملفات جاهزة. انسخ كل ملف إلى المسار الموضح بالاسم.

```kotlin name=build.gradle.kts
// file: build.gradle.kts (project root)
plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
}
```

```kotlin name=app/build.gradle.kts
// file: app/build.gradle.kts
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.dataoptimizer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.dataoptimizer"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildFeatures {
        viewBinding = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.work:work-runtime-ktx:2.10.0")
}
```

```xml name=app/src/main/AndroidManifest.xml
<!-- file: app/src/main/AndroidManifest.xml -->
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.example.dataoptimizer">

    <uses-permission android:name="android.permission.INTERNET" />

    <application
        android:label="Data Optimizer"
        android:allowBackup="true"
        android:theme="@style/Theme.DataOptimizer">
        <activity android:name="com.example.dataoptimizer.ui.MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <service
            android:name="com.example.dataoptimizer.vpn.DataVpnService"
            android:permission="android.permission.BIND_VPN_SERVICE"
            android:exported="false" />
    </application>
</manifest>
```

```kotlin name=app/src/main/kotlin/com/example/dataoptimizer/vpn/DataVpnService.kt
// file: app/src/main/kotlin/com/example/dataoptimizer/vpn/DataVpnService.kt
package com.example.dataoptimizer.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.example.dataoptimizer.data.local.PrefsManager
import com.example.dataoptimizer.util.QuotaCalculator
import kotlinx.coroutines.*
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.coroutines.CoroutineContext

class DataVpnService : VpnService(), CoroutineScope {
    private var vpnInterface: ParcelFileDescriptor? = null
    private var job: Job = Job()
    override val coroutineContext: CoroutineContext
        get() = Dispatchers.IO + job

    private lateinit var prefs: PrefsManager

    @Volatile
    private var sessionRxBytes: Long = 0L
    @Volatile
    private var sessionTxBytes: Long = 0L

    companion object {
        const val NOTIF_CHANNEL = "data_vpn_channel"
        const val NOTIF_ID = 1001
    }

    override fun onCreate() {
        super.onCreate()
        prefs = PrefsManager(this)
        startForegroundWithNotification()
    }

    private fun startForegroundWithNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel =
                NotificationChannel(NOTIF_CHANNEL, "خدمة التحكم بالبيانات", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(channel)
        }
        val notif: Notification = NotificationCompat.Builder(this, NOTIF_CHANNEL)
            .setContentTitle("خدمة Data Optimizer تعمل")
            .setContentText("مراقبة استهلاك البيانات")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .build()
        startForeground(NOTIF_ID, notif)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        launch {
            establishVpn()
            runVpnLoop()
        }
        return START_STICKY
    }

    private fun establishVpn() {
        vpnInterface?.closeQuietly()

        val builder = Builder()
        builder.setSession("DataOptimizerLocalVPN")
            .addAddress("10.0.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .setMtu(1500)

        vpnInterface = builder.establish()
    }

    private suspend fun runVpnLoop() {
        val pfd = vpnInterface ?: return
        val `in` = FileInputStream(pfd.fileDescriptor)
        val buffer = ByteArray(32767)

        while (isActive) {
            val dailyQuotaBytes = QuotaCalculator.getDailyQuotaBytes(this, prefs)
            val usedToday = prefs.getUsedBytesToday()
            if (usedToday >= dailyQuotaBytes) {
                // نفّذ حظر بسيط: لا نعيد توجيه الحزم (نؤخر الحلقة)
                delay(1000)
                continue
            }

            val read = try {
                `in`.read(buffer)
            } catch (e: Exception) {
                -1
            }
            if (read > 0) {
                sessionTxBytes += read
                prefs.addUsedBytes(read.toLong())
            } else if (read == -1) {
                break
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        job.cancel()
        vpnInterface?.closeQuietly()
        stopForeground(true)
    }

    override fun onRevoke() {
        super.onRevoke()
        onDestroy()
    }

    private fun ParcelFileDescriptor?.closeQuietly() {
        try {
            this?.close()
        } catch (e: Exception) {
            // ignore
        }
    }
}
```

```kotlin name=app/src/main/kotlin/com/example/dataoptimizer/util/QuotaCalculator.kt
// file: app/src/main/kotlin/com/example/dataoptimizer/util/QuotaCalculator.kt
package com.example.dataoptimizer.util

import android.content.Context
import com.example.dataoptimizer.data.local.PrefsManager

object QuotaCalculator {
    fun mbToBytes(mb: Double): Long = (mb * 1024.0 * 1024.0).toLong()
    fun bytesToMb(bytes: Long): Double = bytes / (1024.0 * 1024.0)

    fun getDailyQuotaBytes(context: Context, prefs: PrefsManager): Long {
        val monthlyMb = prefs.getQuotaMb()
        val dailyMb = monthlyMb / 30.0
        return mbToBytes(dailyMb)
    }
}
```

```kotlin name=app/src/main/kotlin/com/example/dataoptimizer/workers/ResetQuotaWorker.kt
// file: app/src/main/kotlin/com/example/dataoptimizer/workers/ResetQuotaWorker.kt
package com.example.dataoptimizer.workers

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.dataoptimizer.data.local.PrefsManager
import java.util.Calendar

class ResetQuotaWorker(private val ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    private val prefs = PrefsManager(ctx)
    override suspend fun doWork(): Result {
        val cal = Calendar.getInstance()
        val today = cal.get(Calendar.DAY_OF_YEAR)
        val last = prefs.getLastResetDay()
        if (last != today) {
            prefs.setUsedBytesToday(0L)
            prefs.setLastResetDay(today)
        }
        return Result.success()
    }
}
```

```kotlin name=app/src/main/kotlin/com/example/dataoptimizer/data/local/PrefsManager.kt
// file: app/src/main/kotlin/com/example/dataoptimizer/data/local/PrefsManager.kt
package com.example.dataoptimizer.data.local

import android.content.Context

class PrefsManager(context: Context) {
    private val prefs = context.getSharedPreferences("data_optimizer_prefs", Context.MODE_PRIVATE)

    fun getQuotaMb(): Double = prefs.getString("quota_mb", "1024")?.toDoubleOrNull() ?: 1024.0
    fun setQuotaMb(value: Double) {
        prefs.edit().putString("quota_mb", value.toString()).apply()
    }

    fun getUsedBytesToday(): Long = prefs.getLong("used_bytes_today", 0L)
    fun setUsedBytesToday(value: Long) = prefs.edit().putLong("used_bytes_today", value).apply()
    fun addUsedBytes(delta: Long) {
        val current = getUsedBytesToday()
        setUsedBytesToday(current + delta)
    }

    fun getLastResetDay(): Int = prefs.getInt("last_reset_day", -1)
    fun setLastResetDay(dayOfYear: Int) = prefs.edit().putInt("last_reset_day", dayOfYear).apply()
}
```

```kotlin name=app/src/main/kotlin/com/example/dataoptimizer/vpn/VpnPermissionHelper.kt
// file: app/src/main/kotlin/com/example/dataoptimizer/vpn/VpnPermissionHelper.kt
package com.example.dataoptimizer.vpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService

object VpnPermissionHelper {
    const val REQUEST_VPN = 1000

    fun prepareVpn(activity: Activity): Boolean {
        val intent = VpnService.prepare(activity)
        return if (intent != null) {
            activity.startActivityForResult(intent, REQUEST_VPN)
            false
        } else {
            true
        }
    }
}
```

```xml name=app/src/main/res/layout/activity_main.xml
<!-- file: app/src/main/res/layout/activity_main.xml -->
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:padding="16dp">

    <TextView
        android:id="@+id/quotaText"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="الحصة اليومية: --"
        android:textSize="18sp"
        android:layout_marginBottom="8dp"/>

    <TextView
        android:id="@+id/usageText"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="الاستهلاك: --"
        android:textSize="18sp"
        android:layout_marginBottom="8dp"/>

    <TextView
        android:id="@+id/updatedText"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="آخر تحديث"
        android:layout_marginBottom="12dp"/>

    <EditText
        android:id="@+id/quotaInput"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:hint="أدخل الحصة بالميجابايت"/>

    <Button
        android:id="@+id/saveQuotaButton"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="حفظ الحصة"
        android:layout_marginTop="8dp"/>

    <Button
        android:id="@+id/refreshButton"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="تحديث"
        android:layout_marginTop="8dp"/>

    <Button
        android:id="@+id/startVpnButton"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="بدء خدمة VPN"
        android:layout_marginTop="12dp"/>

    <View
        android:layout_width="match_parent"
        android:layout_height="1dp"
        android:layout_marginTop="16dp"
        android:background="#e0e0e0"/>

    <TextView
        android:id="@+id/footerBy"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="توجيه وبرمجه عبد الحق الغولي"
        android:gravity="center"
        android:textSize="12sp"
        android:layout_marginTop="12dp"/>
</LinearLayout>
```

```xml name=app/src/main/res/values/strings.xml
<!-- file: app/src/main/res/values/strings.xml -->
<resources>
    <string name="app_name">Data Optimizer</string>
    <string name="byline">توجيه وبرمجه عبد الحق الغولي</string>
</resources>
```

```xml name=app/src/main/res/values/themes.xml
<!-- file: app/src/main/res/values/themes.xml -->
<resources>
    <style name="Theme.DataOptimizer" parent="Theme.MaterialComponents.DayNight.DarkActionBar">
        <item name="colorPrimary">@android:color/holo_blue_dark</item>
        <item name="colorPrimaryVariant">@android:color/holo_blue_light</item>
        <item name="colorOnPrimary">@android:color/white</item>
    </style>
</resources>
```

```xml name=app/src/main/res/drawable/card_bg.xml
<!-- file: app/src/main/res/drawable/card_bg.xml -->
<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">
    <solid android:color="#FFFFFF"/>
    <corners android:radius="8dp"/>
    <stroke android:width="1dp" android:color="#DDDDDD"/>
</shape>
```

ثانياً — ملف GitHub Actions لبناء APK تلقائياً
إن وُضِع هذا الملف في .github/workflows/build-android.yml وسيبني APK ويضعه كـ artifact يمكن تنزيله من تبويب Actions.

```yaml name=.github/workflows/build-android.yml
# file: .github/workflows/build-android.yml
name: Build Android APK

on:
  workflow_dispatch:
  push:
    branches:
      - main
      - master

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - name: Install Android SDK dependencies
        uses: reactivecircus/android-emulator-runner@v2
        with:
          api-level: 33
          target: default
          arch: x86_64
          force-avd-creation: false

      - name: Run Gradle assembleDebug
        uses: gradle/gradle-build-action@v2
        with:
          arguments: :app:assembleDebug

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: DataOptimizer-debug-apk
          path: app/build/outputs/apk/debug/app-debug.apk
```

ثالثاً — تعليمات لبناء APK محلياً (مختصر)
- شرط: لديك Android Studio مع Android SDK (API 35 أو 33)، JDK 17.
- افتح المشروع بواسطة Android Studio (File → Open) على مجلد المشروع root.
- إن لم يكن لديك Gradle Wrapper، في Android Studio يمكنك استخدام زر Build → Make Project أو من الطرفية داخل Android Studio شغّل: ./gradlew assembleDebug (إن لم توجد ./gradlew يمكنك إنشاء wrapper محلياً بواسطة الأمر gradle wrapper إذا كان Gradle مثبتاً).
- بعد الانتهاء ستجد APK في: app/build/outputs/apk/debug/app-debug.apk
- انسخ الـ APK إلى جهاز أندرويد وفعّل تثبيت من مصدر غير معروف للمستعرض/مدير الملفات ثم ثبّت.

أو: ارفع المشروع إلى GitHub ثم شغّل الـ Workflow أعلاه (Actions → Build Android APK → Run workflow). بعد نجاح التشغيل نزّل artifact المسمى DataOptimizer-debug-apk → يحتوي app-debug.apk.

رابعاً — تغييرات سلوكية أساسية وقيود
- الـ DataVpnService الموجود هنا يسمح بالتقاط الحزم وقياس البايتات الصادرة عبر واجهة TUN التي تقرأ منها. لكنه لا يعيد توجيه الحزم لخارج الجهاز (أي لا يوفّر اتصالًا بالإنترنت عبر userspace) — هذا كافٍ لتنفيذ سياسة "إسقاط" (Kill Switch) عن طريق عدم إعادة توجيه الحزم. إذا تريد إعادة توجيه فعلية سيتطلب ذلك خطوات متقدمة (native libraries أو بروكسيات).
- يجب أن يطالب التطبيق المستخدم بالموافقة على إنشاء VPN عند بدء الخدمة (VpnPermissionHelper يفعل ذلك).
- بعض الأجهزة تقيّد سلوك VpnService أو تتطلب إعدادات خاصة للطاقة — اختبر على جهاز فعلي.

خامساً — هل تريد أن أقوم بـ:
(أ) توليد ملف Gradle Wrapper والالتزام بكل الملفات في شكل commit/branch إلى مستودع GitHub (أطلب منك توفير owner/repo لأقوم بإنشاء PR أو ملفات مباشرة)،  
أم (ب) أقدّم لك ملف MainActivity.kt محدث ليتضمن زر بدء خدمة الـ VPN والتعامل مع نتيجة الإذن؟  

إذا أردت أستطيع الآن:
- توليد MainActivity.kt محدث يتضمن زر "بدء خدمة VPN" ويتعامل مع VpnPermissionHelper وبدء/إيقاف الخدمة، ثم أعطيك الملف الجاهز للنسخ.
- أو تزويدك بأمر واحد-liner لإنشاء Gradle Wrapper محلياً إذا لا تملك Gradle: "sdk install gradle" غير متوفر على كل أنظمة — سأعطي خطوات آمنة.

ما الذي تريده الآن بالضبط لكي أكمل؟
