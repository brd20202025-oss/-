// file: app/src/main/kotlin/com/example/dataoptimizer/util/QuotaCalculator.kt
package com.example.dataoptimizer.util

import android.content.Context
import com.example.dataoptimizer.data.local.PrefsManager

object QuotaCalculator {
    fun mbToBytes(mb: Double): Long = (mb * 1024.0 * 1024.0).toLong()
    fun bytesToMb(bytes: Long): Double = bytes / (1024.0 * 1024.0)

    fun getDailyQuotaBytes(context: Context, prefs: PrefsManager): Long {
        val monthlyMb = prefs.getQuotaMb()
        val dailyMb = monthlyMb / 30.0
        return mbToBytes(dailyMb)
    }
}