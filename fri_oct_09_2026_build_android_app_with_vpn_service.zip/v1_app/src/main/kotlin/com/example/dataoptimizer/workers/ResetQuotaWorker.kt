// file: app/src/main/kotlin/com/example/dataoptimizer/workers/ResetQuotaWorker.kt
package com.example.dataoptimizer.workers

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.dataoptimizer.data.local.PrefsManager
import java.util.Calendar

class ResetQuotaWorker(private val ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    private val prefs = PrefsManager(ctx)
    override suspend fun doWork(): Result {
        val cal = Calendar.getInstance()
        val today = cal.get(Calendar.DAY_OF_YEAR)
        val last = prefs.getLastResetDay()
        if (last != today) {
            prefs.setUsedBytesToday(0L)
            prefs.setLastResetDay(today)
        }
        return Result.success()
    }
}