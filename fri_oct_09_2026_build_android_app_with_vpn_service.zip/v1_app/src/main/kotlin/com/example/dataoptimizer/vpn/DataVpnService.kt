// file: app/src/main/kotlin/com/example/dataoptimizer/vpn/DataVpnService.kt
package com.example.dataoptimizer.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.example.dataoptimizer.data.local.PrefsManager
import com.example.dataoptimizer.util.QuotaCalculator
import kotlinx.coroutines.*
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.coroutines.CoroutineContext

class DataVpnService : VpnService(), CoroutineScope {
    private var vpnInterface: ParcelFileDescriptor? = null
    private var job: Job = Job()
    override val coroutineContext: CoroutineContext
        get() = Dispatchers.IO + job

    private lateinit var prefs: PrefsManager

    @Volatile
    private var sessionRxBytes: Long = 0L
    @Volatile
    private var sessionTxBytes: Long = 0L

    companion object {
        const val NOTIF_CHANNEL = "data_vpn_channel"
        const val NOTIF_ID = 1001
    }

    override fun onCreate() {
        super.onCreate()
        prefs = PrefsManager(this)
        startForegroundWithNotification()
    }

    private fun startForegroundWithNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel =
                NotificationChannel(NOTIF_CHANNEL, "خدمة التحكم بالبيانات", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(channel)
        }
        val notif: Notification = NotificationCompat.Builder(this, NOTIF_CHANNEL)
            .setContentTitle("خدمة Data Optimizer تعمل")
            .setContentText("مراقبة استهلاك البيانات")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .build()
        startForeground(NOTIF_ID, notif)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        launch {
            establishVpn()
            runVpnLoop()
        }
        return START_STICKY
    }

    private fun establishVpn() {
        vpnInterface?.closeQuietly()

        val builder = Builder()
        builder.setSession("DataOptimizerLocalVPN")
            .addAddress("10.0.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .setMtu(1500)

        vpnInterface = builder.establish()
    }

    private suspend fun runVpnLoop() {
        val pfd = vpnInterface ?: return
        val `in` = FileInputStream(pfd.fileDescriptor)
        val buffer = ByteArray(32767)

        while (isActive) {
            val dailyQuotaBytes = QuotaCalculator.getDailyQuotaBytes(this, prefs)
            val usedToday = prefs.getUsedBytesToday()
            if (usedToday >= dailyQuotaBytes) {
                // نفّذ حظر بسيط: لا نعيد توجيه الحزم (نؤخر الحلقة)
                delay(1000)
                continue
            }

            val read = try {
                `in`.read(buffer)
            } catch (e: Exception) {
                -1
            }
            if (read > 0) {
                sessionTxBytes += read
                prefs.addUsedBytes(read.toLong())
            } else if (read == -1) {
                break
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        job.cancel()
        vpnInterface?.closeQuietly()
        stopForeground(true)
    }

    override fun onRevoke() {
        super.onRevoke()
        onDestroy()
    }

    private fun ParcelFileDescriptor?.closeQuietly() {
        try {
            this?.close()
        } catch (e: Exception) {
            // ignore
        }
    }
}