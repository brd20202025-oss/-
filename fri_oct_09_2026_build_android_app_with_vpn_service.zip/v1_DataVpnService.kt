package com.example.dataoptimizer.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.example.dataoptimizer.data.local.PrefsManager
import com.example.dataoptimizer.util.QuotaCalculator
import kotlinx.coroutines.*
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.coroutines.CoroutineContext

class DataVpnService : VpnService(), CoroutineScope {
    private var vpnInterface: ParcelFileDescriptor? = null
    private var job: Job = Job()
    override val coroutineContext: CoroutineContext
        get() = Dispatchers.IO + job

    private lateinit var prefs: PrefsManager

    // عداد مؤقّت لبايتات الجلسة الحالية
    @Volatile
    private var sessionRxBytes: Long = 0L

    @Volatile
    private var sessionTxBytes: Long = 0L

    companion object {
        const val NOTIF_CHANNEL = "data_vpn_channel"
        const val NOTIF_ID = 1001
    }

    override fun onCreate() {
        super.onCreate()
        prefs = PrefsManager(this)
        startForegroundWithNotification()
    }

    private fun startForegroundWithNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel =
                NotificationChannel(NOTIF_CHANNEL, "خدمة التحكم بالبيانات", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(channel)
        }
        val notif: Notification = NotificationCompat.Builder(this, NOTIF_CHANNEL)
            .setContentTitle("خدمة Data Optimizer تعمل")
            .setContentText("مراقبة استهلاك البيانات")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .build()
        startForeground(NOTIF_ID, notif)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // إعداد وبدء VPN في الخلفية
        launch {
            establishVpn()
            runVpnLoop()
        }
        return START_STICKY
    }

    private fun establishVpn() {
        // إيقاف إنشاءة متعددة
        vpnInterface?.closeQuietly()

        val builder = Builder()
        builder.setSession("DataOptimizerLocalVPN")
            // عنوان افتراضي داخل الشبكة الافتراضية
            .addAddress("10.0.0.2", 32)
            // مسار افتراضي لالتقاط كل الحزم
            .addRoute("0.0.0.0", 0)
        // استثناء التطبيقات المسموح لها (مثال): يمكنك التحكم عبر واجهة المستخدم
        // builder.addAllowedApplication("com.example.app")

        // MTU اختياري
        builder.setMtu(1500)

        vpnInterface = builder.establish()
    }

    private suspend fun runVpnLoop() {
        val pfd = vpnInterface ?: return
        val `in` = FileInputStream(pfd.fileDescriptor)
        val out = FileOutputStream(pfd.fileDescriptor)
        val buffer = ByteArray(32767)

        // عند نفاد الحصة نوقف إعادة التوجيه (ببساطة نتجاهل الحزم)
        while (isActive) {
            // تحقق من الحصة قبل القراءة لمعرفة ما إذا نحتاج إلى إسقاط/حظر
            val dailyQuotaBytes = QuotaCalculator.getDailyQuotaBytes(this, prefs)
            val usedToday = prefs.getUsedBytesToday()
            if (usedToday >= dailyQuotaBytes) {
                // إسقاط الحزم: نقرأ فقط بدون إعادة توجيه أو نؤخر القراءة
                delay(1000) // تقليل استهلاك CPU أثناء الحظر
                continue
            }

            // قراءة بيانات من الواجهة الافتراضية (حزم صادرة من التطبيقات إلى الشبكة)
            val read = try {
                `in`.read(buffer)
            } catch (e: Exception) {
                -1
            }
            if (read > 0) {
                // عدّ البايتات الصادرة
                sessionTxBytes += read
                prefs.addUsedBytes(read.toLong())
                // هنا عادةً يجب عليك إعادة توجيه الحزمة إلى الشبكة الحقيقية (userspace stack أو raw sockets)
                // إذا أردت عرض/إحصاء فقط، يمكنك تجاهل إعادة التوجيه أو implement forwarding لاحقاً.
            } else if (read == -1) {
                break
            }

            // ملاحظة: لقراءة الحزم الواردة يجب فتح socket خارجي وقراءة، أو ضمن بنية إعادة التوجيه.
            // لكن حتى لو لم تعيد توجيه الحزم، قراءة المخرجات تتيحك عدّ ما ترسل التطبيقات.
            // يمكن أيضاً استخدام TrafficStats για قياس إجمالي النظام كاحتياط.
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        job.cancel()
        vpnInterface?.closeQuietly()
        stopForeground(true)
    }

    override fun onRevoke() {
        super.onRevoke()
        onDestroy()
    }

    // مساعدة لإغلاق ParcelFileDescriptor بأمان
    private fun ParcelFileDescriptor?.closeQuietly() {
        try {
            this?.close()
        } catch (e: Exception) {
            // ignore
        }
    }
}