package com.example.dataoptimizer.data.local

import android.content.Context
import java.util.Calendar

class PrefsManager(context: Context) {
    private val prefs = context.getSharedPreferences("data_optimizer_prefs", Context.MODE_PRIVATE)

    fun getQuotaMb(): Double = prefs.getString("quota_mb", "1024")?.toDoubleOrNull() ?: 1024.0
    fun setQuotaMb(value: Double) {
        prefs.edit().putString("quota_mb", value.toString()).apply()
    }

    // استخدام يومي بالبايت
    fun getUsedBytesToday(): Long = prefs.getLong("used_bytes_today", 0L)
    fun setUsedBytesToday(value: Long) = prefs.edit().putLong("used_bytes_today", value).apply()
    fun addUsedBytes(delta: Long) {
        val current = getUsedBytesToday()
        setUsedBytesToday(current + delta)
    }

    // تاريخ آخر إعادة تعيين (باليوم)
    fun getLastResetDay(): Int = prefs.getInt("last_reset_day", -1)
    fun setLastResetDay(dayOfYear: Int) = prefs.edit().putInt("last_reset_day", dayOfYear).apply()
}