package com.example.dataoptimizer.util

import android.content.Context
import com.example.dataoptimizer.data.local.PrefsManager

object QuotaCalculator {
    // تحويل ميجابايت إلى بايت
    fun mbToBytes(mb: Double): Long = (mb * 1024.0 * 1024.0).toLong()

    // تحويل بايت إلى ميجابايت
    fun bytesToMb(bytes: Long): Double = bytes / (1024.0 * 1024.0)

    // إذا المستخدم حدّد حصة شهرية إجمالية، نوزّعها على 30 يوم
    fun getDailyQuotaBytes(context: Context, prefs: PrefsManager): Long {
        val monthlyMb = prefs.getQuotaMb()
        val dailyMb = monthlyMb / 30.0
        return mbToBytes(dailyMb)
    }
}