// داخل MainActivity بعد تهيئة prefs
fun updateUsageUI() {
    val usedBytes = prefs.getUsedBytesToday()
    val dailyQuota = QuotaCalculator.getDailyQuotaBytes(this, prefs)
    binding.usageText.text = DataConverter.formatUsage(usedBytes)
    binding.quotaText.text = DataConverter.formatUsage(dailyQuota)
    val percent = if (dailyQuota == 0L) 0 else (usedBytes * 100 / dailyQuota).toInt()
    if (percent >= 80) {
        // إظهار إشعار/تنبيه للمستخدم عن الاقتراب من الحد
    }
}