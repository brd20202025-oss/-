// مثال مقتطف داخل MainActivity
if (VpnPermissionHelper.prepareVpn(this)) {
    // بدء الخدمة مباشرة
    startService(Intent(this, DataVpnService::class.java))
}
// في onActivityResult تحقّق ثم ابدأ الخدمة إذا تم المنح